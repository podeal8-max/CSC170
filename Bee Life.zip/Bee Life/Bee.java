import greenfoot.*;

public class Bee extends Actor
{
    private int speed = 4;
    private int invuln = 0; 

    public void act()
    {
        handleInput();
        clampToWorld();

     
        Flower f = (Flower)getOneIntersectingObject(Flower.class);
        if (f != null) {
            ((MyWorld)getWorld()).addScore(1);
            Greenfoot.playSound("collect.wav");
            getWorld().removeObject(f);
        }

      
        if (invuln == 0) {
            Raindrop r = (Raindrop)getOneIntersectingObject(Raindrop.class);
            if (r != null) {
                ((MyWorld)getWorld()).loseLife();
                Greenfoot.playSound("hit.wav");
                invuln = 60;                 
                setLocation(getX(), Math.max(0, getY() - 20)); 
            }
        } else {
            invuln--;
        }
    }

    private void handleInput() {
        int x = getX();
        int y = getY();
        if (Greenfoot.isKeyDown("left"))  x -= speed;
        if (Greenfoot.isKeyDown("right")) x += speed;
        if (Greenfoot.isKeyDown("up"))    y -= speed;
        if (Greenfoot.isKeyDown("down"))  y += speed;
        setLocation(x, y);
    }

    private void clampToWorld() {
        World w = getWorld();
        int x = Math.max(0, Math.min(getX(), w.getWidth()-1));
        int y = Math.max(0, Math.min(getY(), w.getHeight()-1));
        if (x != getX() || y != getY()) setLocation(x, y);
    }
    private void safePlay(String name) {
    try { 
        safePlay("collect.wav");
        safePlay("hit.wav");
    } 
    catch (IllegalArgumentException e) { 
       
    }
}
}
