import greenfoot.*;  
import java.util.List;

public class MyWorld extends World
{
   
    private int score = 0;
    private int lives = 3;
    private int timeFrames = 90 * 60; 

    public MyWorld()
    {
        super(600, 400, 1);
        prepare();
    }

    public void prepare()
    {
        
        addObject(new Bee(), getWidth()/2, getHeight()/2);

       
        for (int i = 0; i < 5; i++) spawnFlower();

      
        for (int i = 0; i < 3; i++) spawnRaindrop();
    }

    public void act()
    {
        
        timeFrames--;

        
        if (getObjects(Flower.class).size() < 5) spawnFlower();

        
        if (getObjects(Raindrop.class).size() < 6 && timeFrames % 300 == 0) {
            spawnRaindrop();
        }

        
        showText("Score: " + score, 60, 20);
        showText("Lives: " + lives, 160, 20);
        showText("Time: " + (timeFrames / 60), 260, 20);

        
        if (timeFrames <= 0) endGame("Time Up! Game Over");
    }

    
    public void addScore(int n) {
        score += n;
        if (score >= 15) endGame("You Win!");
    }

    public void loseLife() {
        lives--;
        if (lives <= 0) endGame("Game Over");
    }

 

    private void spawnFlower() {
        int x = Greenfoot.getRandomNumber(getWidth());
        int y = Greenfoot.getRandomNumber(getHeight());
        addObject(new Flower(), x, y);
    }

    private void spawnRaindrop() {
        int x = Greenfoot.getRandomNumber(getWidth());
        addObject(new Raindrop(), x, 0);
    }
    

    
    private void endGame(String msg) {
    showText(msg, getWidth()/2, getHeight()/2);

    // choose sound based on message
    if (msg.toLowerCase().contains("win")) {
        safePlay("win.wav");
    } else {
        safePlay("lose.wav");
    }

    Greenfoot.stop();
}
private void safePlay(String name) {
    try {
        Greenfoot.playSound(name);
    } catch (IllegalArgumentException e) {
        // ignore missing file errors so the game doesn't crash
    }
}
}





