import greenfoot.*;

public class Raindrop extends Actor
{
    private int speed = 3;

    public void act()
    {
        setLocation(getX(), getY() + speed);

      
        World w = getWorld();
        if (getY() > w.getHeight()-1) {
            setLocation(Greenfoot.getRandomNumber(w.getWidth()), 0);
        }
    }

}