import greenfoot.*;

public class Flower extends Actor
{
    public void act() {
        
    }
}